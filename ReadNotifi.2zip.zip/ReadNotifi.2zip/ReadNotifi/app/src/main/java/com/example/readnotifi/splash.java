package com.example.readnotifi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class splash extends AppCompatActivity {
   CoordinatorLayout coordinatorLayout;
    TextView btnLogin,btnSignup,btnRead;
  Animation animZoomIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        btnLogin =(TextView)findViewById(R.id.btn_Login);
        btnSignup=(TextView)findViewById(R.id.btn_sign);
        btnRead=(TextView)findViewById(R.id.btn_Read);
        getSupportActionBar().hide();
        animZoomIn = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.text_ani);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(splash.this, LogIn.class);
                startActivity(i);
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(splash.this, SignUp.class);
                startActivity(i);
            }
        });
        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Toast.makeText(splash.this, "please login", Toast.LENGTH_SHORT).show();
//                Snackbar snackbar = Snackbar
//                        .make(" ", "please login", Snackbar.LENGTH_LONG);
//                snackbar.show();
            }
        });
    }

    public   void Snackbar(){


 }
}