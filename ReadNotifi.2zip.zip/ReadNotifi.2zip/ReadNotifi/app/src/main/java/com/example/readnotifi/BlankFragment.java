package com.example.readnotifi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.HashMap;


public class BlankFragment extends BottomSheetDialogFragment {
    public SendMessages sendMessages;
    String s1,pass;
    TextView textView;
    boolean b = true;
    HashMap<String,String>s2;
    SharedPreferences sharedpreferences;
    SharedPreferences sh;

    public BlankFragment() { }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogStyle); }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_blank, container, false);
        sharedpreferences = getContext().getSharedPreferences("MySharedPref",Context.MODE_PRIVATE);
    s2=new HashMap<String ,String>();
    textView = (TextView)v.findViewById(R.id.txt_password);
    TextView btnc =(TextView) v.findViewById(R.id.btn_sbmit);
        TextView btncan =(TextView) v.findViewById(R.id.btn_cancel);

        EditText editText =(EditText)v.findViewById(R.id.edit_passw);
        btnc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pass = editText.getText().toString();

                b= false;
                if (pass.isEmpty()) {
                    Toast.makeText(getContext(), "message is empty", Toast.LENGTH_SHORT).show();

                } else {
                    textView.setText(pass.trim());
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("three", pass.trim());
                    editor.apply();
                    Toast.makeText(getContext(), "submited.............", Toast.LENGTH_SHORT).show();
                } }
        });

        btncan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        return v; }
    @Override
    public void onResume() {
        super.onResume();
        sh = getContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        s1 = sh.getString("three", "");
        sh.getAll();
      //  s2= (HashMap<String, String>) sh.getAll();
        Log.d(" ", "onClick: .................."+s1);
        Log.e(" ", "hashmap.................."+ sh.getAll());
        textView.setText(s1);
    }
    public interface SendMessages {
        void iAmMSG(String msg);
    }
}