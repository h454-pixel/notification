package com.example.readnotifi;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class Method {
    public Activity activity;
    public Context context;
    public SharedPreferences preff;
    public SharedPreferences.Editor editor;
    private final String myPreference = "Instagram";
    public String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    public String IS_FIRST_TIME_LAUNCHMain = "secondtime";
    public String IS_Cancel = "alarm";

    public static boolean isDownload = true;

    public Method(Activity activity) {
        this.activity = activity;
        preff = activity.getSharedPreferences(myPreference, 0); // 0 - for private mode
        editor = preff.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }
    public void setFirstTimeLaunchSecond(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCHMain, isFirstTime);
        editor.commit();
    }


    public boolean isFirstTimeLaunchSecond() {
        return preff.getBoolean(IS_FIRST_TIME_LAUNCHMain, true);
    }

    public boolean isFirstTimeLaunch() {
        return preff.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

}



