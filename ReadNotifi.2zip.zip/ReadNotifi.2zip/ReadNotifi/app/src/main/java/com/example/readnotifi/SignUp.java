package com.example.readnotifi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;

public class SignUp extends AppCompatActivity {

     TextView signIn,signUp,btnface,btngmail;
     EditText edtemail,edtpass;
     ImageView img;
     private FirebaseAuth firebaseAuth;
     private ProgressBar progressBar;
     Context context;
    public  static int RC_SIGN_IN=100;
    GoogleSignInClient mGoogleSignInClient;
    CallbackManager callbackManager;
    AccessToken accessToken;
    boolean isLoggedIn,preventMain =true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        context= this;
        firebaseAuth =FirebaseAuth.getInstance();
        findid();
        buttoncall();
        getSupportActionBar().hide();
        funon();
        glogin();

    }
    private void glogin() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

       btngmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);

                Log.e("tag", "..............onClick:gmailgmail............... " +Thread.currentThread().getName());
            }
        });

    }

    private void buttoncall() {
        btnface.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    facebooksign();
                }
            });
        }

    private void funon() {
        signUp.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View v) {
                                          String email = edtemail.getText().toString().trim();
                                          String password = edtpass.getText().toString().trim();

                                          if (TextUtils.isEmpty(email)) {
                                              Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();

                                          } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                                              Toast.makeText(getApplicationContext(), "Enter valid email  address!", Toast.LENGTH_SHORT).show();

                                          }else if (TextUtils.isEmpty(password)) {
                                              Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                                          }else if (password.length()<6) {
                                              Toast.makeText(getApplicationContext(), "password is short", Toast.LENGTH_SHORT).show();
                                          }
                                          else {
                                              progressBar.setVisibility(View.VISIBLE);
                                              signUp.setVisibility(View.INVISIBLE);
                                              Log.e("tag", "......googlePhone()........................... " +Thread.currentThread().getName());
                                              frebaseSignup( email ,password);
                                          }
                                      }
        }
        );
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SignUp.this, LogIn.class);
                startActivity(i);
            }
        });
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SignUp.this,LogIn.class);
                startActivity(i);
            }
        });
    }
    private void frebaseSignup(String email ,String password) {
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            progressBar.setVisibility(View.GONE);
                            signUp.setVisibility(View.VISIBLE);
                            Toast.makeText(SignUp.this, "Sigin  completed." + task.getException(),
                                    Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SignUp.this, LogIn.class);
                            intent.putExtra("x", false);
                            startActivity(intent);


                        } else {
                            progressBar.setVisibility(View.GONE);
                            progressBar.setVisibility(View.GONE);
                            signUp.setVisibility(View.VISIBLE);
                            Log.e("tag", ".......not exit........................... " + task.getException());
                            // finish();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    Toast.makeText(SignUp.this, "Email is invalid .please try right email pattern", Toast.LENGTH_SHORT).show();
                }
                if (e instanceof FirebaseAuthUserCollisionException) {
                    Toast.makeText(SignUp.this, "This email address already used by another account", Toast.LENGTH_SHORT).show();
                }
                if (e instanceof FirebaseNetworkException) {

                    Toast.makeText(SignUp.this, "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                }
                if (e instanceof FirebaseTooManyRequestsException) {
                    Toast.makeText(SignUp.this, "many failed login attempts so try after sometime", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void facebooksign() {
        callbackManager = CallbackManager.Factory.create();

        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));
            LoginManager.getInstance().registerCallback(callbackManager,
                    new FacebookCallback<LoginResult>() {
                        @Override
                        public void onSuccess(LoginResult loginResult) {
                            startActivity(new Intent(SignUp.this, AlarmSetPass.class));
                        }
                        @Override
                        public void onCancel() {
                        }
                        @Override
                        public void onError(FacebookException exception) {
                        }
                    });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(callbackManager!=null) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            Log.e("tag", ".......handleSignInResult1111.............onClick:forget............... " +Thread.currentThread().getName());
            handleSignInResult(task);
        }
    }
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {

        Log.e("tag", ".......handleSignInResult.22222222............onClick:forget............... " +Thread.currentThread().getName());


        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

            if (acct != null) {
                String personName = acct.getDisplayName();
                String personGivenName = acct.getGivenName();
                String personFamilyName = acct.getFamilyName();
                String personEmail = acct.getEmail();
                String personId = acct.getId();
                Uri personPhoto = acct.getPhotoUrl();
                Toast.makeText(this, "Welcome Login in completed", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(SignUp.this,AlarmSetPass.class));

        } catch (ApiException e) {
            Log.d("massage",e.toString());
        }
    }

    private void findid() {
        signIn =(TextView)findViewById(R.id.txt_signin);
        signUp =(TextView)findViewById(R.id.btn_signUp);
        btnface =(TextView)findViewById(R.id.btn_face);
        btngmail =(TextView)findViewById(R.id.btn_google);
        img =(ImageView)findViewById(R.id.img);
        edtemail=(EditText)findViewById(R.id.edt_email);


        edtpass=(EditText) findViewById(R.id.edt_pass);
        progressBar=(ProgressBar) findViewById(R.id.progress_circular_1);
    }
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        if(currentUser != null){
            //reload();
        }
    }
}












