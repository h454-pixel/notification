package com.example.readnotifi;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SetPass extends AppCompatActivity {
 ImageView img;
 EditText editemail;
 TextView txtsend;
    private FirebaseAuth auth;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpas);

        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
 img =(ImageView)findViewById(R.id.img);
 editemail=(EditText)findViewById(R.id.edt_email);
 txtsend =(TextView)findViewById(R.id.btn_send);
 progressBar =(ProgressBar)findViewById(R.id.progress_send);
 img.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View v) {
         Intent i = new Intent(SetPass.this, LogIn.class);
         startActivity(i);


     }
 });

        txtsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = editemail.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplication(), "Enter your registered email id", Toast.LENGTH_SHORT).show();

                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(getApplicationContext(), "Enter valid email  address!", Toast.LENGTH_SHORT).show();
                }
                else {

                    progressBar.setVisibility(View.VISIBLE);
                    txtsend.setVisibility(View.INVISIBLE);
                    auth.sendPasswordResetEmail(email)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()) {
                                        Toast.makeText(SetPass.this, "We have sent you instructions to reset your password in your registered email", Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                        txtsend.setVisibility(View.VISIBLE);
                                        finish();
                                    }

                                    // progressBar.setVisibility(View.GONE);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            if (e instanceof FirebaseAuthInvalidUserException) {
                                progressBar.setVisibility(View.GONE);
                                txtsend.setVisibility(View.VISIBLE);
                                Toast.makeText(SetPass.this, "This User Not Found ,try right email", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
            }
        });

    }
}