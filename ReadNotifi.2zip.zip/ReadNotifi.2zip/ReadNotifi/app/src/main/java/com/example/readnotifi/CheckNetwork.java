package com.example.readnotifi;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CheckNetwork extends AppCompatActivity {
  Context context;
   //Boolean netwokvalue;
   AlarmAlert  alarmAlert;
    Intent intent;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        context =getApplicationContext();
        alarmAlert = new AlarmAlert(context);
        intent =new Intent(CheckNetwork.this,MainActivity.class);
      //  registerNetworkCallback(context);
    }
    public static   void  registerNetworkCallback( Context  context)
    {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkRequest.Builder builder = new NetworkRequest.Builder();

            connectivityManager.
                    registerDefaultNetworkCallback
                            (new ConnectivityManager.NetworkCallback(){
                                @Override public void onAvailable(Network network) {
                                //  netwokvalue =false;
                                    Log.e("" ,".................................onAvailable" );
                                    //Toast.makeText(context, "network available", Toast.LENGTH_SHORT).show();
                                }
                                @Override
                                public void onLost(Network network) {


                                    // Global Static Variable
                                    Toast.makeText(context, "no internet connection", Toast.LENGTH_SHORT).show();
                                     Log.e("" ,".........................................onLost");
                                                                   }
                                                               }

                                                               );
        }catch (Exception e){
            Log.d("" ,".............check.Exception..........newtwork" +e);

        }
    }
}

