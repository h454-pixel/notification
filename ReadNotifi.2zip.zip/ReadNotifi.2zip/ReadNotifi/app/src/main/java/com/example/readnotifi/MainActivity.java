package com.example.readnotifi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt;
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetSequence;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.SyncStateContract;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.example.readnotifi.databinding.ActivitySettingBinding;
import com.facebook.CallbackManager;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.internal.Constants;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Arrays;
import java.util.Locale;

import static android.service.controls.ControlsProviderService.TAG;

public  class MainActivity extends AppCompatActivity {
    SharedPreferences sh;
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
    private static final String ACTION_NOTIFICATION_LISTENER_SETTINGS = "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS";
    private ImageChangeBroadcastReceiver imageChangeBroadcastReceiver;
    private AlertDialog enableNotificationListenerAlertDialog;
    ModeChangeReciever ModeChangeReceiver;
    TextView txtAlarm, txtpass;
    ImageView imgSinout,imgsetpass,imgoff;
    CheckBox chwifi, chCharge, chBlue, chloca, chmobi, chsim;
    AlarmAlert alarmAlert;
    LinearLayout linearsetalarm,linearsetpass,linearlogout;
    String text,password;
    ActivitySettingBinding binding;
    public static int RC_SIGN_IN = 100;
    GoogleSignInClient mGoogleSignInClient;
    CheckNetwork network;
    boolean b ,firstsug;
    String t;
    Method method;
    SwitchMaterial aSwitch;
    Boolean button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        method =new Method(MainActivity.this);

        sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        getSupportActionBar().hide();
        initview();
        requestSmsPermission();
        googleSignOut();

       if(!isNotificationServiceEnabled()) {
            enableNotificationListenerAlertDialog = buildNotificationServiceAlertDialog();
            enableNotificationListenerAlertDialog.show();
        }



        Log.d(" ", "..###################.##################firstsug........................" + firstsug);

       ModeChangeReceiver = new ModeChangeReciever();
        // Finally we register a receiver to tell the MainActivity when a notification has been received
        imageChangeBroadcastReceiver = new ImageChangeBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.example.readnotifi");
        LocalBroadcastManager.getInstance(this).registerReceiver(imageChangeBroadcastReceiver, new IntentFilter("Msg"));
        alarmAlert = new AlarmAlert(this);





        password= sh.getString("three", "");

        Log.d(" ","..................sh.getString...................."+password);
    }

    private void initview() {
        txtAlarm = binding.txtAlarm;
        chwifi = binding.checkboxWifi;
        chCharge = binding.cbxCharge;
        chBlue = binding.cbxBlue;
        chloca = binding.cbxLoca;
        chmobi = binding.cbxMobidata;
        chsim = binding.cbxSim;
        imgSinout = binding.imgLogout;
        imgsetpass=binding.imgSetpass;
        imgoff =binding.alaramOff;
        aSwitch=binding.switch1;
        linearsetalarm=binding.linearSetmes;
        linearsetpass=binding.linearSetpas;
        linearlogout=binding.linearLogout;

        alarmAlert = new AlarmAlert(getApplicationContext());
        // network  = new CheckNetwork(getApplicationContext());
        }

    private void googleSignOut() {
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);


       linearlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                     builder.setMessage("Do you want to logout ?");
                     builder.setTitle("Alert !");
                     builder.setCancelable(false);
                     builder.setPositiveButton(
                                "Yes",
                                new DialogInterface
                                        .OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which)
                                    {
                                        emailsignOut();
                                        signOut();
                                        fLogOut();
                                        Toast.makeText(MainActivity.this, "succesfully log out", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(MainActivity.this,LogIn.class));
                                    }
                                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which)
                                    {
                                        dialog.cancel();
                                    }
                                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }



        });
    }

    private void emailsignOut() {
        FirebaseAuth.getInstance().signOut();
    }

    private void fLogOut() {
        LoginManager.getInstance().logOut();
    }

    private void signOut() {
        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                      //  finish();
                    }
                }); }

    @Override
    protected void onStart() {
        super.onStart();

        Log.e(TAG, "onCreate: *************buttonbuttonbuttonbutton*****..............."+button);
        chBlue.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Log.d(TAG, "onCreate: *************CHECK box*****...............");
           if(isChecked) {
               IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
               registerReceiver(ModeChangeReceiver, filter);
           }
        });
        chCharge.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Log.d(TAG, "onCreate: *************CHECK box*****...............");
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            registerReceiver(ModeChangeReceiver, filter);

        });
        chloca.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Log.d(TAG, "onCreate: *************CHECK box*****...............");
            IntentFilter filter = new IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION);
            registerReceiver(ModeChangeReceiver, filter);

        });
        chsim.setOnCheckedChangeListener((buttonView, isChecked) -> {

            TelephonyManager telephonyManager = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
//SIM 1 Number
            @SuppressLint("MissingPermission") String mSimPhoneNumber1 = telephonyManager.getLine1Number();

            try {
                if (mSimPhoneNumber1.isEmpty()) {
                    Log.d(TAG, "onCreate: *************CHECK box*****...1.mSimPhoneNumber1..........." + mSimPhoneNumber1);

                } else {

                    Log.d(TAG, "onCreate: *************CHECK box*****...2.mSimPhoneNumber1..........." + mSimPhoneNumber1);
                }
            } catch (NullPointerException e) {
                alarmAlert.aleartaction();
                Toast.makeText(MainActivity.this, "No SimCard", Toast.LENGTH_SHORT).show();

            }

        });

        chwifi.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked) {
                IntentFilter filter = new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
                Intent intent = new Intent(this, ModeChangeReciever.class);
                registerReceiver(ModeChangeReceiver, filter);
            }
        });


        chmobi.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if(isChecked) {
                IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
                registerReceiver(ModeChangeReceiver, filter);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d(TAG, "onCreate: ****** onCheckedChanged******switch*****..............."+isChecked);
                if (isChecked) {
                    button = true;
                    linearsetalarm.setEnabled(true);
                   linearsetpass.setEnabled(true);
                   linearsetalarm.setOnClickListener(new View.OnClickListener() {
                       @Override
                        public void onClick(View v) {
                            BlankFragment bottomSheetFragment = new BlankFragment();
                            bottomSheetFragment.show(getSupportFragmentManager(), bottomSheetFragment.getTag());

                            Log.d(TAG, "onCreate: ****** ifisChecked*******switch*****..............."+isChecked);
                        }
                    });
                    linearsetpass.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            FragmentCancel bottomSheet = new FragmentCancel();
                            bottomSheet.show(getSupportFragmentManager(), bottomSheet.getTag());
                            Log.d(TAG, "onCreate: ****** ifisChecked*******switch*****..............."+isChecked);
                        }
                    });

                } else {
                    button = false;
                    Log.d(TAG, "onCreate: *************switch*****..............."+isChecked);
                    linearsetalarm.setEnabled(false);
                    linearsetpass.setEnabled(false);
                }
            }
        }
        );

        linearsetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               alarmAlert.alramoff();



            }
        });

    }
    @Override
    protected void onDestroy() {

   //     unregisterReceiver(ModeChangeReceiver);
      // unregisterReceiver(imageChangeBroadcastReceiver);
          binding =null;
        super.onDestroy();
    }

    @Override
    protected void onRestart() {

        if (method.isFirstTimeLaunchSecond()) {
            AppDemo();
            method.setFirstTimeLaunchSecond(false);

        }
        super.onRestart();
    }
    private boolean isNotificationServiceEnabled() {
        String pkgName = getPackageName();
        final String flat = Settings.Secure.getString(getContentResolver(),
                ENABLED_NOTIFICATION_LISTENERS);
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (int i = 0; i < names.length; i++) {
                final ComponentName cn = ComponentName.unflattenFromString(names[i]);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }



    public class ImageChangeBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String title = intent.getStringExtra("title");
            text = intent.getStringExtra("text");
            changeInterceptedNotificationImage(text);
        }
    }
    private AlertDialog buildNotificationServiceAlertDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(R.string.notification_listener_service);
        alertDialogBuilder.setMessage(R.string.notification_listener_service_explanation);
        alertDialogBuilder.setPositiveButton(R.string.yes,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        startActivity(new Intent(ACTION_NOTIFICATION_LISTENER_SETTINGS));

                    }
                });
        alertDialogBuilder.setNegativeButton(R.string.no,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        return (alertDialogBuilder.create());
    }
    private void requestSmsPermission() {
        String permission = Manifest.permission.READ_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if (grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "permission not granted", Toast.LENGTH_SHORT).show();
            }
        }


    }


    private void changeInterceptedNotificationImage(String notification) {

       if(notification.equalsIgnoreCase(password)){
           alarmAlert.aleartaction();
           Log.d(" ", "...#changeInterceptedNotificationImage......................."+password);
           Log.d(" ", "...##################1111111111........................" + notification);

        }
                
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(MainActivity.this, splash.class));

    }

    public void AppDemo(){
        new MaterialTapTargetSequence()

                .addPrompt(new MaterialTapTargetPrompt.Builder(MainActivity.this)
                .setTarget(findViewById(R.id.switch_1))
                .setPrimaryText("Turn on  this switch always to create message alarm and cancel alarm")
                .setSecondaryText("tap anywhere for next guide circle")
                .setFocalPadding(R.dimen.font_login)
                .setFocalColour(getResources().getColor(R.color.white))
                .setIcon(R.drawable.ic_baseline_access_alarms_24)
                .setIdleAnimationEnabled(true)
                .create(), 15000)
                 .show()
           .addPrompt(new MaterialTapTargetPrompt.Builder(MainActivity.this)
                .setTarget(findViewById(R.id.img_setpass))
                .setPrimaryText("Click on the icon to create passcode , ignore if you have already created")
                .setSecondaryText("for whatsapp,telegram, phone messages")
                .setFocalPadding(R.dimen.font_login)
                .setFocalColour(getResources().getColor(R.color.white))
                .setIcon(R.drawable.ic_outline_lock_24)
                .setIdleAnimationEnabled(true)
                .create(), 15000)
                .show();
    }
}




