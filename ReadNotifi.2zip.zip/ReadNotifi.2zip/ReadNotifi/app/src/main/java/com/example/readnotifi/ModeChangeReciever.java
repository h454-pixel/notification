package com.example.readnotifi;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.util.Log;
import android.widget.Toast;

public class ModeChangeReciever extends BroadcastReceiver {
    AlarmAlert alert;
//Context context;
    CheckNetwork checkNetwork;
    Boolean b =false,wb =false;
    int wifiStateExtra;

    @Override
    public void onReceive(Context context, Intent intent) {
        alert = new AlarmAlert(context);





        if (intent.getAction().matches(LocationManager.PROVIDERS_CHANGED_ACTION)) {
            Toast.makeText(context, "Location is on", Toast.LENGTH_SHORT).show();

            alert.aleartaction();
        }

        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        float batteryPct = level * 100 / (float) scale;

        Log.d(" ", "bettery level................ " + batteryPct);

        if (batteryPct <= 90.0) {
            alert.aleartaction();
            Toast.makeText(context, "Battery low", Toast.LENGTH_SHORT).show();
        }


        String action = intent.getAction();
        if (action != null) {
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);

                switch (state) {
                    case BluetoothAdapter.STATE_ON:
                        Toast.makeText(context, " bluetooth on ", Toast.LENGTH_SHORT).show();
                        alert.aleartaction();
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        // Toast.makeText(context, " b  on ", Toast.LENGTH_SHORT).show();
                        break;
                }
            }

            wifiStateExtra = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE,
                    WifiManager.WIFI_STATE_UNKNOWN);

            switch (wifiStateExtra) {
                case WifiManager.WIFI_STATE_ENABLED:

                    break;
                case WifiManager.WIFI_STATE_DISABLED:

                   alert.aleartaction();
                    Toast.makeText(context, "wifi off", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
        try {
                ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkRequest.Builder builder = new NetworkRequest.Builder();
                if (connectivityManager != null) {
                    connectivityManager.
                            registerDefaultNetworkCallback
                                    (new ConnectivityManager.NetworkCallback() {
                                         @Override
                                         public void onAvailable(Network network) {
                                             //  netwokvalue =false;
                                             Log.e("", ".................................onAvailable");
                                           //  Toast.makeText(context, "network available", Toast.LENGTH_SHORT).show();
                                         }

                                         @Override
                                         public void onLost(Network network) {
                                             alert.aleartaction();

                                             // Global Static Variable
                                             Toast.makeText(context, "network not available", Toast.LENGTH_SHORT).show();
                                             Log.e("", ".........................................onLost");
                                         }
                                    }
                                    );
                }

            } catch (Exception e) {
                Log.d("", ".............check.Exception..........newtwork" + e);
                //    Variable.isConnected = false;
            }
            Log.d("", "..........................network value");

    }
    }






















































