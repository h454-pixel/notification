package com.example.readnotifi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.Login;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;

public class LogIn extends AppCompatActivity {
    TextView signup, forget,btn,gSign,fsignin;
    EditText edtemail,edtpass;
    ImageView img;
    public  static int RC_SIGN_IN=100;
    GoogleSignInClient mGoogleSignInClient;
    CallbackManager callbackManager;
    AccessToken   accessToken;
    boolean isLoggedIn,preventMain =true;
    private FirebaseAuth auth;
    ProgressBar progressBar;
    CheckNetwork checkNetwork;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        auth = FirebaseAuth.getInstance();
        context =this;
        Idcall();
        buttoncall();
        googlePhone();
        checkNetwork =new CheckNetwork();
       ////////////facebook login//////////////////////////


       GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build();
       mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        gSign.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);

            Log.e("tag", "..............onClick:gmailgmail............... " +Thread.currentThread().getName());
        }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    private void googlePhone() {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtemail.getText().toString().trim();
                String password = edtpass.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();

            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(getApplicationContext(), "Enter valid email  address!", Toast.LENGTH_SHORT).show();

                }else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                }else if (password.length()<6) {
                    Toast.makeText(getApplicationContext(), "password is short", Toast.LENGTH_SHORT).show();
                }
                else {
                    progressBar.setVisibility(View.VISIBLE);
                    btn.setVisibility(View.INVISIBLE);
                    Log.e("tag", "......googlePhone()........................... " +Thread.currentThread().getName());
                    Taskk asyncTask = new Taskk(email, password);
                    asyncTask.execute();

                }
            }
        });

    }

    private void buttoncall() {

        accessToken = AccessToken.getCurrentAccessToken();
        isLoggedIn = accessToken != null && !accessToken.isExpired();

        if (isLoggedIn){
            startActivity(new Intent(LogIn.this,MainActivity.class));
        }
        else {
            fsignin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    facebooksign();
                }
            });
        }

        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(LogIn.this, SetPass.class);
                startActivity(i);
            /// / /...................onClick:forget............... " +Thread.currentThread().getName());
            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LogIn.this, splash.class);
                startActivity(i);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LogIn.this,SignUp.class);
                startActivity(i);

                Log.e("tag", ".....******************************.........onClick:signup............... " +Thread.currentThread().getName());
            }
        });
    }

    private void Idcall() {
        signup =(TextView)findViewById(R.id.txt_signup);
        forget =(TextView)findViewById(R.id.txt_forget_pass);
        btn = (TextView) findViewById(R.id.btn_login);
        img =(ImageView)findViewById(R.id.img);
        gSign=(TextView)findViewById(R.id.btn_google);
        fsignin=(TextView)findViewById(R.id.btn_face);
        edtemail=(EditText)findViewById(R.id.edt_email);
        edtpass=(EditText)findViewById(R.id.edt_pass);
        progressBar=(ProgressBar)findViewById(R.id.progress_Log);
    }

    private void facebooksign() {
        callbackManager = CallbackManager.Factory.create();

        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        startActivity(new Intent(LogIn.this,AlarmSetPass.class));

                    }
                    @Override
                    public void onCancel() {

                    }
                    @Override
                    public void onError(FacebookException exception) {
                      //  Toast.makeText(this, " network error", Toast.LENGTH_SHORT).show();
                    }
                }); }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(callbackManager!=null) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            Log.e("tag", ".......handleSignInResult1111.............onClick:forget............... " +Thread.currentThread().getName());

            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {

        Log.e("tag", ".......handleSignInResult.22222222............onClick:forget............... " +Thread.currentThread().getName());


        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

            if (acct != null) {
                String personName = acct.getDisplayName();
                String personGivenName = acct.getGivenName();
                String personFamilyName = acct.getFamilyName();
                String personEmail = acct.getEmail();
                String personId = acct.getId();
                Uri personPhoto = acct.getPhotoUrl();
                Toast.makeText(this, "Welcome Login in completed", Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(LogIn.this,AlarmSetPass.class));

        } catch (ApiException e) {
            Toast.makeText(this, " network error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
          if(account!= null){
                 Toast.makeText(this, "Signed in", Toast.LENGTH_SHORT).show();
                 startActivity(new Intent(LogIn.this,MainActivity.class));
             }
    }

    class Taskk extends AsyncTask<Void,Void, Void> {
        String email;
        String password;

        public Taskk(String email, String password) {
            this.email = email;
            this.password = password;
        }

        @Override
        protected Void doInBackground(Void... Voids) {
            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Log.e("tag", ".......mGoogleSignInClient.............if............... " + Thread.currentThread().getName());
                                progressBar.setVisibility(View.GONE);
                                btn.setVisibility(View.VISIBLE);
                                FirebaseUser user = auth.getCurrentUser();
                                Log.e("tag", ".......not exit...else1........................ " + user);

                                Log.e("tag", ".......not exit........................... " + task.getException());
                            } else {
                                Log.e("tag", ".......mGoogleSignInClient.....else.2.............. " + Thread.currentThread().getName());
                                progressBar.setVisibility(View.GONE);
                                btn.setVisibility(View.VISIBLE);
                                startActivity(new Intent(LogIn.this, AlarmSetPass.class));
                                Toast.makeText(LogIn.this, "Welcome login Successful", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    if (e instanceof FirebaseAuthInvalidUserException) {
                        Toast.makeText(LogIn.this, "This User Not Found , Create A New Account", Toast.LENGTH_SHORT).show();
                    }
                    if (e instanceof FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(LogIn.this, "The Password Is Invalid, Please Try Valid Password", Toast.LENGTH_SHORT).show();
                    }
                    if (e instanceof FirebaseNetworkException) {
                        Toast.makeText(LogIn.this, "Please Check Your Connection", Toast.LENGTH_SHORT).show();
                    }
                    if (e instanceof FirebaseTooManyRequestsException) {
                        Toast.makeText(LogIn.this, "many failed login attempts so try after sometime", Toast.LENGTH_SHORT).show();
                    }

                }
            });

            return null;
        }
    }
}