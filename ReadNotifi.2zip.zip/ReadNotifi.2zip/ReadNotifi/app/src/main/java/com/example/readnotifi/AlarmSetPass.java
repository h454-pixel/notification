package com.example.readnotifi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AlarmSetPass extends AppCompatActivity {
    Method method;
    TextView btncreate;
    EditText editpass;
    ImageView img_back;
  SharedPreferences  sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarmsetpass);
        sharedpreferences =getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);

        method =new Method(AlarmSetPass.this);
         getSupportActionBar().hide();
     editpass=(EditText)findViewById(R.id.edt_firstpas);
     btncreate=( TextView)findViewById(R.id.btn_create);
     img_back=(ImageView) findViewById(R.id.img_back);

///this is false first time.......
        if (!method.isFirstTimeLaunch()) {
            startActivity(new Intent(AlarmSetPass.this, MainActivity.class));

        }

  btncreate.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
          String pass =editpass.getText().toString();
          if (TextUtils.isEmpty(pass)) {
              Toast.makeText(getApplicationContext(), "Enter passcode ", Toast.LENGTH_SHORT).show();

          }else {
              SharedPreferences.Editor editor = sharedpreferences.edit();
              editor.putString("three", pass.trim());
              editor.commit();
              launchHomeScreen();
              startActivity(new Intent(AlarmSetPass.this, MainActivity.class));
          }
      }
  });
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AlarmSetPass.this, "please enter passcode and press create", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void launchHomeScreen() {
        method.setFirstTimeLaunch(false);
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "please enter passcode and press create", Toast.LENGTH_SHORT).show();
    }
}
