package com.example.readnotifi;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.provider.Telephony;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.SpannableString;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.service.controls.ControlsProviderService.TAG;

public class  NotificationListenerExampleService extends NotificationListenerService {
    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor myEdit;
    String content;
    String title;
    String  packagesms;
    String text;


    @RequiresApi(api = Build.VERSION_CODES.R)

    @Override
    public void onCreate() {

        super.onCreate();
        context = getApplicationContext();
        sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        myEdit = sharedPreferences.edit();
        packagesms = Telephony.Sms.getDefaultSmsPackage(context);
        Log.d(TAG, "onCreate: ..pck.............." + packagesms);

    }
    private static final class ApplicationPackageNames {
        public static final String WHATSAPP_PACK_NAME = "com.whatsapp";
        public static final String TELEGRAM_PACK_NAME = "org.telegram.messenger";

    }

    public static final class InterceptedNotificationCode {
        public static final int SMS_CODE=1;
        public static final int WHATSAPP_CODE = 2;
        public static final int TELEGRAM_CODE = 3;
        public static final int OTHER_NOTIFICATIONS_CODE = 4; // We ignore all notification with code == 4
    }


    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn){
        int notificationCode = matchNotificationCode(sbn);

        if(notificationCode != InterceptedNotificationCode.OTHER_NOTIFICATIONS_CODE){
            outputNotificationData(sbn);}
    }

    public void   outputNotificationData(StatusBarNotification sbn) {
//    String ticker ="";
//   if(sbn.getNotification().tickerText !=null) {
//      ticker = sbn.getNotification().tickerText.toString();
//  }
        String pack = sbn.getPackageName();
        Bundle extras = sbn.getNotification().extras;
        if ((Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)) {
            Parcelable b[] = (Parcelable[]) extras.get(Notification.EXTRA_MESSAGES);

            if (b == null) {
             
                for (Parcelable tmp : b) {

                  Bundle msgBundle = (Bundle) tmp;
              }
            }else {
                Log.d(TAG, "onCreate: *************CHECK OUT*****..............." +content);
            }
        }
        Intent msgrcv = new Intent("Msg");
        msgrcv.putExtra("package", pack);
        msgrcv.putExtra("title", title);
         LocalBroadcastManager.getInstance(context).sendBroadcast(msgrcv);
    }
    private int matchNotificationCode(StatusBarNotification sbn) {
      String packageName = sbn.getPackageName();

         if(packageName.equals(ApplicationPackageNames.TELEGRAM_PACK_NAME)){
            return(InterceptedNotificationCode.TELEGRAM_CODE);
         }
        else if(packageName.equals( ApplicationPackageNames.WHATSAPP_PACK_NAME)){
            return(InterceptedNotificationCode.WHATSAPP_CODE);
        }
        else if(packageName.equals(packagesms)){
             return(InterceptedNotificationCode.SMS_CODE);
         }
        else{
            return(InterceptedNotificationCode.OTHER_NOTIFICATIONS_CODE);
        }
    }
}
